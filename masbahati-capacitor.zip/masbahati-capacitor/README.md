# مسبحتي — مشروع Android (Capacitor)

مشروع جاهز بالكامل، الكود الأصلي (`www/index.html`) وملفات Android موجودة. محتاج بس تبنيه على جهازك.

## المتطلبات قبل البدء
1. **Node.js** (نسخة 18 أو أحدث) — https://nodejs.org
2. **Android Studio** (أحدث نسخة) — https://developer.android.com/studio
3. اتصال إنترنت عادي (Gradle هيحمل مكتبات أول مرة)

## خطوات البناء

### 1. فك ضغط المشروع وافتح الترمينال جواه
```bash
cd masbahati-capacitor
```

### 2. تثبيت الحزم
```bash
npm install
```

### 3. مزامنة مشروع Android
```bash
npx cap sync android
```

### 4. افتح المشروع في Android Studio
```bash
npx cap open android
```
(أو افتح Android Studio يدويًا واختر Open → فولدر `android` جوه المشروع)

### 5. ابني الـ APK
جوه Android Studio:
- من القائمة العلوية: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- أول مرة هياخد وقت أطول عشان Gradle بيحمل المكتبات
- لما يخلص هتلاقي إشعار "APK(s) generated successfully" — دوس على **locate** عشان توصل للملف
- المسار عادة بيكون: `android/app/build/outputs/apk/debug/app-debug.apk`

الملف ده جاهز تنزله على أي موبايل أندرويد وتجربه فورًا (لازم تفعّل "تثبيت من مصادر غير معروفة" في إعدادات الموبايل).

## للنشر على Google Play (اختياري)
لو عايز تنشره فعليًا، محتاج:
1. **Signed APK/AAB**: من نفس قائمة Build، اختار **Generate Signed Bundle / APK** بدل الخطوة رقم 5، واعمل keystore جديد (احفظه في مكان آمن، مش هتقدر تسترجعه لو ضاع).
2. استخدم **Android App Bundle (.aab)** بدل APK عادي — ده اللي Google Play بيطلبه دلوقتي.
3. أيقونة المتجر عالية الدقة موجودة جاهزة: `play_store_icon_512.png` (512×512).

## هيكل المشروع
```
masbahati-capacitor/
├── www/index.html          ← كود التطبيق نفسه (HTML/CSS/JS)
├── android/                 ← مشروع Android الكامل (Gradle)
├── capacitor.config.json    ← إعدادات التطبيق (الاسم، الحزمة، الألوان)
├── package.json
└── play_store_icon_512.png  ← أيقونة جاهزة للمتجر
```

## إيه اللي اتظبط عشان التطبيق ميقفلش لما تخرج منه
- التطبيق دلوقتي **تطبيق أندرويد حقيقي (native)** مش صفحة ويب في المتصفح — بيفضل شغال في الخلفية زي أي تطبيق تاني.
- البيانات بتتحفظ فورًا (localStorage + حفظ إضافي لما التطبيق يروح للخلفية عبر `App.addListener("appStateChange")`).
- زرار الرجوع (Back) في الأندرويد بيرجعك للشاشة الرئيسية جوه التطبيق بدل ما يقفله على طول.
- الاهتزاز بيستخدم الـ Haptics الأصلي للنظام (أدق من اهتزاز المتصفح).

## تعديل التطبيق لاحقًا
عدّل في `www/index.html` بس، وبعدين شغّل:
```bash
npx cap sync android
```
عشان التعديلات تتنقل لمشروع الأندرويد، وبعدين ابني الـ APK تاني.

## اسم التطبيق والحزمة
- الاسم المعروض: **مسبحتي**
- Package ID: `com.masbahati.app`
(تقدر تغيّرهم من `capacitor.config.json` وبعدين `npx cap sync android`)
