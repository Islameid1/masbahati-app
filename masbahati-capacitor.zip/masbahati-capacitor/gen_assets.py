#!/usr/bin/env python3
"""Generate Android icon + splash assets for masbahati app - geometric tasbih motif."""
import math
from PIL import Image, ImageDraw

DEEP_GREEN = (15, 43, 36, 255)      # #0f2b24
MID_GREEN  = (27, 77, 62, 255)      # #1b4d3e
GOLD       = (212, 175, 55, 255)    # #d4af37
GOLD_DIM   = (163, 135, 43, 255)    # #a3872b
CREAM      = (243, 236, 217, 255)   # #f3ecd9

def radial_bg(size, c1, c2):
    """Simple radial gradient background."""
    img = Image.new("RGBA", (size, size), c2)
    px = img.load()
    cx, cy = size/2, size*0.38
    maxd = math.hypot(size, size) * 0.62
    for y in range(size):
        for x in range(size):
            d = math.hypot(x-cx, y-cy) / maxd
            d = min(d, 1)
            r = int(c1[0] + (c2[0]-c1[0])*d)
            g = int(c1[1] + (c2[1]-c1[1])*d)
            b = int(c1[2] + (c2[2]-c1[2])*d)
            px[x, y] = (r, g, b, 255)
    return img

def draw_tasbih_motif(draw, cx, cy, r, bead_color, ring_color, stroke_w):
    """Draw a circular ring of tasbih beads - the app's signature glyph."""
    # outer thin ring
    draw.ellipse([cx-r, cy-r, cx+r, cy+r], outline=ring_color, width=max(2, stroke_w//3))
    # beads around the ring
    n_beads = 11
    bead_r = r * 0.115
    orbit_r = r * 0.78
    for i in range(n_beads):
        angle = (2*math.pi/n_beads) * i - math.pi/2
        bx = cx + orbit_r * math.cos(angle)
        by = cy + orbit_r * math.sin(angle)
        is_marker = (i % 3 == 0)
        col = ring_color if is_marker else bead_color
        rr = bead_r * (1.25 if is_marker else 1.0)
        draw.ellipse([bx-rr, by-rr, bx+rr, by+rr], fill=col)
    # center dot (the "counter" focal point)
    cr = r * 0.30
    draw.ellipse([cx-cr, cy-cr, cx+cr, cy+cr], fill=ring_color)
    inner = r * 0.16
    draw.ellipse([cx-inner, cy-inner, cx+inner, cy+inner], fill=(15,43,36,255))

def make_icon(size, padding_ratio=0.0, background=True):
    img = radial_bg(size, MID_GREEN, DEEP_GREEN) if background else Image.new("RGBA",(size,size),(0,0,0,0))
    draw = ImageDraw.Draw(img)
    cx = cy = size/2
    r = size/2 * (1 - padding_ratio) * 0.72
    draw_tasbih_motif(draw, cx, cy, r, CREAM, GOLD, max(2, size//40))
    return img

def make_foreground(size):
    """Adaptive icon foreground - transparent bg, motif only, smaller for safe zone."""
    img = Image.new("RGBA", (size, size), (0,0,0,0))
    draw = ImageDraw.Draw(img)
    cx = cy = size/2
    r = size/2 * 0.42  # adaptive icons need ~66% safe zone
    draw_tasbih_motif(draw, cx, cy, r, CREAM, GOLD, max(2, size//40))
    return img

def make_splash(w, h):
    img = radial_bg(max(w,h), MID_GREEN, DEEP_GREEN).resize((w,h))
    # re-render properly at target aspect
    img = Image.new("RGBA", (w, h), DEEP_GREEN)
    draw = ImageDraw.Draw(img)
    # subtle radial glow behind center
    cx, cy = w/2, h/2
    glow_r = min(w,h) * 0.35
    steps = 40
    for i in range(steps, 0, -1):
        t = i/steps
        rr = glow_r * t
        alpha_col = tuple(int(MID_GREEN[c] + (DEEP_GREEN[c]-MID_GREEN[c])*(1-t)) for c in range(3))
        draw.ellipse([cx-rr, cy-rr, cx+rr, cy+rr], fill=alpha_col+(255,))
    r = min(w, h) * 0.16
    draw_tasbih_motif(draw, cx, cy, r, CREAM, GOLD, max(3, min(w,h)//80))
    return img.convert("RGB")

RES = "android/app/src/main/res"

# Standard launcher icons (legacy, square, with background baked in)
launcher_sizes = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}
for folder, sz in launcher_sizes.items():
    icon = make_icon(sz, padding_ratio=0.08, background=True)
    icon.save(f"{RES}/{folder}/ic_launcher.png")
    # round variant - same art, circular mask
    mask = Image.new("L", (sz, sz), 0)
    ImageDraw.Draw(mask).ellipse([0,0,sz,sz], fill=255)
    round_icon = Image.new("RGBA", (sz,sz), (0,0,0,0))
    round_icon.paste(icon, (0,0), mask)
    round_icon.save(f"{RES}/{folder}/ic_launcher_round.png")

# Adaptive icon foreground (transparent, used with ic_launcher_background.xml)
foreground_sizes = {
    "mipmap-mdpi": 108,
    "mipmap-hdpi": 162,
    "mipmap-xhdpi": 216,
    "mipmap-xxhdpi": 324,
    "mipmap-xxxhdpi": 432,
}
for folder, sz in foreground_sizes.items():
    fg = make_foreground(sz)
    fg.save(f"{RES}/{folder}/ic_launcher_foreground.png")

# Splash screens - portrait and landscape at each density
splash_sizes = {
    "drawable-port-mdpi": (480, 800),
    "drawable-port-hdpi": (720, 1280),
    "drawable-port-xhdpi": (960, 1600),
    "drawable-port-xxhdpi": (1440, 2560),
    "drawable-port-xxxhdpi": (1920, 3200),
    "drawable-land-mdpi": (800, 480),
    "drawable-land-hdpi": (1280, 720),
    "drawable-land-xhdpi": (1600, 960),
    "drawable-land-xxhdpi": (2560, 1440),
    "drawable-land-xxxhdpi": (3200, 1920),
}
for folder, (w, h) in splash_sizes.items():
    sp = make_splash(w, h)
    sp.save(f"{RES}/{folder}/splash.png", quality=92)

# default splash.png (drawable/)
default_splash = make_splash(1080, 1920)
default_splash.save(f"{RES}/drawable/splash.png")

# Play Store hi-res icon (512x512, no rounding, for store listing)
store_icon = make_icon(512, padding_ratio=0.10, background=True)
store_icon.convert("RGB").save("play_store_icon_512.png")

print("All icon and splash assets generated.")
