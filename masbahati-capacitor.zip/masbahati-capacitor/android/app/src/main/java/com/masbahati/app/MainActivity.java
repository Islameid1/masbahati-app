package com.masbahati.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
